// BouncingCircle.cpp
// Edited by: PUT YOUR NAME HERE, and DATE
//
// This program illustrates some basic graphics functions, control structures,
// and ways to use variables.
//
// Key Commands:
// G - Toggle Gravity
// T - Toggle Trails
// C - Toggle changing colors
// Q or ESC - Quit
//
// Click mouse to change position of the circle

#include "graphics.h"

int main()
{
	//Variable Declarations

	bool keepGoing = true;       // keep running while this is true
	bool eraseTrails = true;     // erase previous object by drawing it in black
	bool gravityOn = false;      // turn on gravity, which changes velocity
	bool changeColorsOn = false; // Constantly change colors

	char keyPressed;
	int mouseX, mouseY;
	int currentColor = RED;

	// Variables to keep track of position, previous position,
	// and velocity

	double pointX1, pointY1; // Current position of point 1
	double prevX1, prevY1;   // Previous position of point 1
	double xVel1, yVel1;     // Velocity of point 1

	// Set Initial Position
	pointX1 = 140.2;
	pointY1 = 150.1;

	// Set Initial Velocity
	xVel1 = 7.18;
	yVel1 = 4.42;

	// Open a graphics window size 800 pixels wide x 600 pixels high
	initwindow(800, 600);

	// TASK FOUR: Draw a couple other shapes here









	// Main Loop - Keep running until user quits (while keepGoing is true)
	while (keepGoing) {
		delay(60);

		// -------------- Move and Control the Point Positions ---------------

		// Remember previous position so we can erase it later
		prevX1 = pointX1;
		prevY1 = pointY1;

		// Bounce off walls by reversing velocity if it's near edge
		// Bounce off left/right wall

		if (pointX1+xVel1 > 770.0 || pointX1+xVel1 < 30.0) {
			xVel1 = xVel1 * -1.0; //multiplying by -1 changes the direction
		}

		// Bounce off top/bottom walls
		if (pointY1+yVel1 > 570.0 || pointY1+yVel1 < 30.0) {
			yVel1 *= -1.0; // another way to multiply by -1
		}

		// FIRST TASK HERE: add 0.3 to Y Velocity






		// SECOND TASK: put an IF statement around the above line
		//              and make it so the Y Velocity is changed only when
		//              "gravityOn" is true.
		//              See the "eraseTrails" example above as a guide.






		// Move the position (Add Velocity to Position)
		pointX1 += xVel1;
		pointY1 += yVel1;

		// Erase old object if eraseTrails is on
		if (eraseTrails) {
			setcolor(BLACK);
			setfillstyle(SOLID_FILL, BLACK);
			fillellipse((int)prevX1, (int)prevY1, 20, 20);
		}

		// Change current color if changeColorsOn is true
		if (changeColorsOn) {
			setcolor(currentColor);
			setfillstyle(SOLID_FILL, currentColor);
			// Cycle through colors 1 to 15 (0 is black)
			currentColor = ((currentColor + 1) % 15) + 1;
		}
		else {
			setcolor(BLACK); //black outline, to see better with trails on
			setfillstyle(SOLID_FILL, WHITE); //white interior
		}

		// -------------- Draw Object in new Position ---------------

		// Draw object in new position
		// Draw filled in circle at pointX1, pointY1
		fillellipse((int)pointX1, (int)pointY1, 20, 20);

		// -------------- Check to see if a key has been pressed ---------------------
		if (kbhit()) {
			keyPressed = getch();

			// KEY: Q or ESC pressed
			if (keyPressed == 'q' || keyPressed == 'Q' || keyPressed == 0x1b) {
				keepGoing = false;
			}// end if (Q)

			//Toggle Trails with T key
			if (keyPressed == 't' || keyPressed == 'T') {
				if (eraseTrails) {
					eraseTrails = false;
				}
				else {
					eraseTrails = true;
				}
			}// end if (T)

			// Toggle Gravity with G key

			// THIRD TASK: Write code that toggles "gravityOn" when G is pressed
			//             Use the example of "eraseTrails" above as a sample.
			//             but look for the "G" key, and change gravityOn








			//Toggle Change Colors with C key
			if (keyPressed == 'c' || keyPressed == 'C') {
				if (changeColorsOn) {
					changeColorsOn = false;
				}
				else {
					changeColorsOn = true;
				}
			}

		}//end if kbhit()

		// -------------- Check to see if a mouse was clicked ---------------------
		if (ismouseclick(WM_LBUTTONUP)) {
			getmouseclick(WM_LBUTTONUP, mouseX, mouseY);
			// Move object to that position
			pointX1 = mouseX;
			pointY1 = mouseY;
		}//end if ismouseclick()

	} // end while kbhit

	closegraph(); // shut down the graphics window
	return 0;
} // end main()
